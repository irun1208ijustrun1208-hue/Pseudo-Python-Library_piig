# piig

Pygame-CE 기반 UI/유틸리티 모듈.

## 설치
```bash
pip install pygame-ce
pip install piig-1.0.1-packaged.zip
# 또는 압축 풀고
pip install -e .
```

## 예제 실행
```bash
python examples/test_screen.py
```
