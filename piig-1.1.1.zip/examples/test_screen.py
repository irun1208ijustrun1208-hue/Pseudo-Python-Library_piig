import pygame
from piig import UI, ThemeManager, Camera, RhythmClock

pygame.init()
screen = pygame.display.set_mode((960, 540))
pygame.display.set_caption("piig test screen")
clock = pygame.time.Clock()

ui = UI()
theme = ThemeManager()
camera = Camera()
rc = RhythmClock(bpm=120)

power_on = True
text_value = "Hello"
slider_val = 0.5
dropdown_choice = "Option 1"

running = True
while running:
    events = pygame.event.get()
    for e in events:
        if e.type == pygame.QUIT:
            running = False

    ui.set_events(events)  # 1.0.1 API

    screen.fill((30, 30, 30))

    ui.text(screen, "piig Test UI", 20, 20)

    if ui.button(screen, 20, 60, 160, 36, "Apply Theme"):
        theme.apply(ui)

    power_on, _ = ui.toggle(screen, 20, 110, 160, 36, "Power", power_on)
    text_value, _ = ui.textbox(screen, 20, 160, 200, 36, text_value)
    slider_val, _ = ui.slider(screen, 20, 210, 200, 20, slider_val)
    dropdown_choice, _ = ui.dropdown(screen, 20, 250, 200, 36,
                                     ["Option 1", "Option 2", "Option 3"],
                                     dropdown_choice)

    ui.text(screen, f"Camera zoom: {getattr(camera,'zoom_level',1.0):.2f}", 20, 300)
    ui.text(screen, f"Beat: {rc.get_beat():.2f}", 20, 340)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
