
import pygame
from .camera import Camera
from .simpleui import UI
from .keys import Keys
from .uikit import set_current as _ui_set_current

class App:
    def __init__(self, width=1280, height=720, title="piig", fps=60, background=(18,18,22), palette=None):
        pygame.mixer.pre_init(frequency=48000, size=-16, channels=2, buffer=512)
        pygame.init()
        self.screen = pygame.display.set_mode((width,height), pygame.RESIZABLE)
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.fps = fps
        self.background = background
        self.camera = Camera()
        self.ui = UI(palette=palette)
        self.keys = Keys()
        self._upd=None; self._draw=None; self._evt=None
        self._dragging=False; self._last=(0,0)

    def on_update(self, fn): self._upd=fn; return fn
    def on_draw(self, fn): self._draw=fn; return fn
    def on_event(self, fn): self._evt=fn; return fn

    def run(self):
        running=True
        while running:
            events = pygame.event.get()
            for e in events:
                if e.type==pygame.QUIT: running=False
                elif e.type==pygame.WINDOWRESIZED: self.screen = pygame.display.set_mode((e.x,e.y), pygame.RESIZABLE)
                elif e.type==pygame.MOUSEBUTTONDOWN and e.button==2: self._dragging=True; self._last=e.pos
                elif e.type==pygame.MOUSEBUTTONUP and e.button==2: self._dragging=False
                elif e.type==pygame.MOUSEWHEEL:
                    self.camera.zoom(0.1*e.y, pygame.mouse.get_pos(), self.screen.get_size())
                if self._evt: self._evt(e)
            if self._dragging and pygame.mouse.get_focused():
                x,y=pygame.mouse.get_pos(); dx,dy=x-self._last[0], y-self._last[1]
                self.camera.move(-dx, -dy); self._last=(x,y)
            self.keys.update_from(events)
            self.ui.set_events(events)
            _ui_set_current(self.ui)
            dt = self.clock.tick(self.fps)/1000.0
            if self._upd: self._upd(dt)
            self.screen.fill(self.background)
            if self._draw: self._draw(self.screen, self.ui)
            pygame.display.flip()

    def quit(self):
        pygame.event.post(pygame.event.Event(pygame.QUIT))
