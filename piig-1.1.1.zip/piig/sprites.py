
import pygame
from pygame.math import Vector2
class Sprite:
    def __init__(self, image, pos=(0,0)):
        self.image=image; self.pos=Vector2(pos); self.scale=1.0; self.rot=0.0; self.alpha=255
    def draw(self, screen, camera, screen_size):
        img=pygame.transform.rotozoom(self.image, -self.rot, camera.zoom_level*self.scale); img.set_alpha(self.alpha)
        x,y=camera.to_screen(self.pos, screen_size); r=img.get_rect(center=(x,y)); screen.blit(img, r)
    def move(self, dx,dy): self.pos.x+=dx; self.pos.y+=dy
