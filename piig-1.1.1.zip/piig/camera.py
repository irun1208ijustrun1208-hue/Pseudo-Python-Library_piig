
from pygame.math import Vector2
class Camera:
    def __init__(self):
        self.pos = Vector2(0,0)
        self.zoom_level = 1.0
        self.min_zoom = 0.25
        self.max_zoom = 5.0
    def move(self, dx, dy):
        self.pos.x += dx / self.zoom_level
        self.pos.y += dy / self.zoom_level
    def zoom(self, delta, focus_screen_pos, screen_size):
        prev_world = self.to_world(focus_screen_pos, screen_size)
        self.zoom_level = max(self.min_zoom, min(self.max_zoom, self.zoom_level * (1.0 + delta)))
        new_screen = self.to_screen(prev_world, screen_size)
        off = (focus_screen_pos[0] - new_screen[0], focus_screen_pos[1] - new_screen[1])
        self.move(-off[0], -off[1])
    def to_screen(self, world_pos, screen_size):
        v = Vector2(world_pos) - self.pos
        v *= self.zoom_level
        v += Vector2(screen_size[0]*0.5, screen_size[1]*0.5)
        return (int(v.x), int(v.y))
    def to_world(self, screen_pos, screen_size):
        from pygame.math import Vector2 as V2
        v = V2(screen_pos) - V2(screen_size[0]*0.5, screen_size[1]*0.5)
        v /= self.zoom_level
        v += self.pos
        return (v.x, v.y)
