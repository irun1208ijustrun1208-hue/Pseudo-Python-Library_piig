
import pygame
class FontManager:
    def __init__(self):
        pygame.font.init()
        self.candidates = ['Malgun Gothic','Apple SD Gothic Neo','Pretendard','Noto Sans CJK KR','Noto Sans KR','NanumGothic','Arial Unicode MS','Arial']
    def get(self, size=18):
        for name in self.candidates:
            try:
                f = pygame.font.SysFont(name, size)
                if f.render("가나다라", True, (255,255,255)).get_width() > 0:
                    return f
            except Exception:
                pass
        return pygame.font.SysFont(None, size)
    def from_path(self, path, size=18):
        try: return pygame.font.Font(path, size)
        except Exception: return self.get(size)
