import pygame
from .fonts import FontManager

DEFAULT = {
    "text": (235,235,240),
    "panel": (40,40,48),
    "panel_header": (55,55,65),
    "button": (100,100,110),
    "button_hover": (140,180,255),
    "slider": (90,90,100),
    "accent": (120,170,255),
    "line": (200,200,210),
    "shape": (60,60,68),
    "focus": (180,220,255)
}

class UI:
    def __init__(self, font=None, size=18, palette=None):
        self.font = font or FontManager().get(size)
        self.palette = palette or DEFAULT
        self._events = []
        self._state = {}

    def set_events(self, events):
        self._events = list(events) if events else []

    def text(self, screen, s, x, y, color=None, align="topleft"):
        color = color or self.palette["text"]
        img = self.font.render(str(s), True, color)
        rect = img.get_rect(); setattr(rect, align, (x,y))
        screen.blit(img, rect); return rect

    def box(self, screen, x, y, w, h, color=None, radius=8, border=0, border_color=None):
        r = pygame.Rect(x,y,w,h)
        pygame.draw.rect(screen, color or self.palette["shape"], r, border_radius=radius)
        if border>0:
            pygame.draw.rect(screen, border_color or self.palette["line"], r, width=border, border_radius=radius)
        return r

    def line(self, screen, x1,y1,x2,y2, color=None, width=2):
        pygame.draw.line(screen, color or self.palette["line"], (x1,y1),(x2,y2), width)

    def circle(self, screen, x,y,r, color=None, border=0):
        pygame.draw.circle(screen, color or self.palette["accent"], (int(x),int(y)), int(r), border)

    def panel(self, screen, x,y,w,h, header=None):
        self.box(screen, x,y,w,h, self.palette["panel"], 10)
        if header:
            self.box(screen, x,y,w,28, self.palette["panel_header"], 10)
            self.text(screen, header, x+8, y+6)

    def button(self, screen, x,y,w,h, label):
        mouse = pygame.mouse.get_pos()
        rect = pygame.Rect(x, y, w, h)
        hover = rect.collidepoint(mouse)
        self.box(screen, x,y,w,h, self.palette["button_hover"] if hover else self.palette["button"], 8)
        self.text(screen, label, x+w//2, y+h//2, align="center")
        clicked = any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and rect.collidepoint(e.pos) for e in self._events)
        return clicked

    def slider(self, screen, x, y, w, h, value):
        st = self._get(('slider',x,y,w,h), {'drag':False})
        value = max(0.0, min(1.0, float(value)))
        rect = self.box(screen, x,y,w,h, self.palette["slider"], 8)
        knob_x = int(x + value*w)
        pygame.draw.circle(screen, self.palette["button_hover"], (knob_x, y+h//2), max(6, h//2-2))
        nv = value
        for e in self._events:
            if e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and rect.collidepoint(e.pos):
                nv = (e.pos[0]-x)/w
            elif e.type==pygame.MOUSEMOTION and getattr(e, "buttons", (0,0,0))[0] and rect.collidepoint(e.pos):
                nv = (e.pos[0]-x)/w
        return max(0.0, min(1.0, nv))

    def _get(self, key, default):
        if key not in self._state: self._state[key]=default
        return self._state[key]

    def textbox(self, screen, key, x,y,w,h, value="", placeholder="", maxlen=0, password=False, numeric=False):
        st = self._get(key, {"text": str(value), "focus": False, "caret": len(str(value)), "blink":0.0})
        changed = False
        rect = pygame.Rect(x,y,w,h)
        if any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and rect.collidepoint(e.pos) for e in self._events):
            st["focus"]=True
        elif any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and not rect.collidepoint(e.pos) for e in self._events):
            st["focus"]=False
        for e in self._events:
            if not st["focus"]: break
            if e.type == pygame.TEXTINPUT:
                text = e.text
                if numeric:
                    text = "".join(ch for ch in text if ch.isdigit() or ch in ".-")
                if text:
                    new = st["text"][:st["caret"]] + text + st["text"][st["caret"]:]
                    if maxlen<=0 or len(new)<=maxlen:
                        st["text"]=new; st["caret"]+=len(text); changed=True
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_BACKSPACE and st["caret"]>0:
                    st["text"]=st["text"][:st["caret"]-1] + st["text"][st["caret"]:]
                    st["caret"]-=1; changed=True
                elif e.key == pygame.K_DELETE and st["caret"]<len(st["text"]):
                    st["text"]=st["text"][:st["caret"]] + st["text"][st["caret"]+1:]; changed=True
                elif e.key == pygame.K_LEFT:
                    st["caret"]=max(0, st["caret"]-1)
                elif e.key == pygame.K_RIGHT:
                    st["caret"]=min(len(st["text"]), st["caret"]+1)
                elif e.key == pygame.K_HOME:
                    st["caret"]=0
                elif e.key == pygame.K_END:
                    st["caret"]=len(st["text"])
        col = self.palette["focus"] if st["focus"] else self.palette["shape"]
        self.box(screen, x,y,w,h, col, 6, border=2, border_color=self.palette["line"])
        shown = ("*"*len(st["text"])) if password else st["text"]
        if shown:
            self.text(screen, shown, x+8, y+h//2, align="midleft")
        elif placeholder:
            self.text(screen, placeholder, x+8, y+h//2, color=(150,150,160), align="midleft")
        if st["focus"]:
            st["blink"] = (st.get("blink",0)+1) % 60
            if st["blink"]<30:
                prefix = ("*"*st["caret"]) if password else st["text"][:st["caret"]]
                caret_x = x+8 + self.font.size(prefix)[0]
                self.line(screen, caret_x, y+6, caret_x, y+h-6, self.palette["text"], 1)
        return st["text"], changed, st["focus"]

    def checkbox(self, screen, key, x,y, label, checked=False):
        st = self._get(key, {"checked": bool(checked)})
        box = self.box(screen, x, y, 20, 20, self.palette["shape"], 4, border=2)
        if st["checked"]:
            pygame.draw.line(screen, self.palette["accent"], (x+4,y+10),(x+9,y+15),3)
            pygame.draw.line(screen, self.palette["accent"], (x+9,y+15),(x+16,y+5),3)
        self.text(screen, label, x+28, y+10, align="midleft")
        if any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and box.collidepoint(e.pos) for e in self._events):
            st["checked"] = not st["checked"]
        return st["checked"]

    def toggle(self, screen, key, x,y, w=48, h=24, on=False):
        st = self._get(key, {"on": bool(on)})
        r = pygame.Rect(x,y,w,h)
        bg = self.palette["accent"] if st["on"] else self.palette["button"]
        self.box(screen, x,y,w,h, bg, h//2)
        knob_x = x + (w-h if st["on"] else 0)
        self.box(screen, knob_x, y, h, h, self.palette["panel_header"], h//2)
        if any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and r.collidepoint(e.pos) for e in self._events):
            st["on"] = not st["on"]
        return st["on"]

    def dropdown(self, screen, key, x,y, w, options, value=None):
        st = self._get(key, {"open": False, "value": value if value is not None else (options[0] if options else None)})
        header = pygame.Rect(x,y,w,28)
        self.box(screen, x,y,w,28, self.palette["button"], 6)
        self.text(screen, str(st["value"]), x+8, y+14, align="midleft")
        if any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and header.collidepoint(e.pos) for e in self._events):
            st["open"] = not st["open"]
        if st["open"] and options:
            list_h = 24*len(options)
            self.box(screen, x, y+28, w, list_h, self.palette["panel"], 6, border=2)
            for i,opt in enumerate(options):
                rr = pygame.Rect(x+2, y+30+i*24, w-4, 22)
                hover = rr.collidepoint(pygame.mouse.get_pos())
                self.box(screen, rr.x, rr.y, rr.w, rr.h, self.palette["panel_header"] if hover else self.palette["panel"], 4)
                self.text(screen, str(opt), rr.x+8, rr.y+11, align="midleft")
                if any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and rr.collidepoint(e.pos) for e in self._events):
                    st["value"]=opt; st["open"]=False
        if st["open"] and any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 and not header.collidepoint(e.pos) for e in self._events):
            st["open"]=False
        return st["value"]

    def progress(self, screen, x,y,w,h, value):
        value = max(0.0, min(1.0, float(value)))
        self.box(screen, x,y,w,h, self.palette["panel_header"], h//2)
        self.box(screen, x,y,int(w*value),h, self.palette["accent"], h//2)

    def image(self, screen, img, x,y, scale=1.0):
        if hasattr(img, "get_width"):
            surf = img
        else:
            try:
                surf = pygame.image.load(img).convert_alpha()
            except Exception:
                return
        if scale != 1.0:
            surf = pygame.transform.smoothscale(surf, (int(surf.get_width()*scale), int(surf.get_height()*scale)))
        screen.blit(surf, (x,y))

# Injected close handlers
def _dropdown_close_on_escape(events, open_flag_get, open_flag_set):
    for e in events:
        if getattr(e,'type',None)==pygame.KEYDOWN and getattr(e,'key',None)==pygame.K_ESCAPE:
            open_flag_set(False)
