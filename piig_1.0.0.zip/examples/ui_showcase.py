import pygame
from piig import UI, ThemeManager
def run():
    pygame.init()
    screen = pygame.display.set_mode((960,540))
    clock = pygame.time.Clock()
    ui = UI()
    theme = ThemeManager()
    running=True
    power_on = True
    while running:
        events = pygame.event.get()
        for e in events:
            if e.type==pygame.QUIT: running=False
        screen.fill((18,18,20))
        ui.begin(screen, events)
        ui.label(20,20,"UI Showcase")
        # Sample widget calls guarded
        if hasattr(ui,'button') and ui.button(20,60,160,36,"Apply Theme"):
            if hasattr(theme,'apply'):
                theme.apply(ui)
        ui.end()
        pygame.display.flip()
        clock.tick(60)
    pygame.quit()

if __name__=='__main__':
    run()
