
from .simpleui import DEFAULT
PALETTES = {
    "dark": DEFAULT,
    "light": {
        "text": (20,20,22), "panel": (230,230,235), "panel_header": (210,210,220),
        "button": (200,200,210), "button_hover": (120,160,255),
        "slider": (190,190,200), "accent": (80,120,255),
        "line": (60,60,70), "shape": (210,210,220), "focus": (240,245,255)
    },
    "retro": {
        "text": (255,255,197), "panel": (0,48,32), "panel_header": (0,64,40),
        "button": (0,96,64), "button_hover": (64,255,160),
        "slider": (0,80,56), "accent": (64,255,160),
        "line": (64,255,160), "shape": (0,72,48), "focus": (0,90,64)
    },
    "neon": {
        "text": (225,255,255), "panel": (10,10,18), "panel_header": (24,24,36),
        "button": (40,40,70), "button_hover": (255,0,200),
        "slider": (60,60,96), "accent": (0,255,200),
        "line": (0,255,200), "shape": (32,32,56), "focus": (30,60,100)
    }
}
class ThemeManager:
    def __init__(self, palette=None):
        self.palette = palette or DEFAULT
    def apply(self, ui):
        ui.palette = self.palette
