
_current = None
def set_current(ui): 
    global _current; _current = ui
class _NS:
    def _require(self):
        if _current is None: raise RuntimeError("UI context not set. Use within @app.on_draw.")
        return _current
    def text(self, screen, *a, **k): return self._require().text(screen, *a, **k)
    def box(self, screen, *a, **k): return self._require().box(screen, *a, **k)
    def line(self, screen, *a, **k): return self._require().line(screen, *a, **k)
    def circle(self, screen, *a, **k): return self._require().circle(screen, *a, **k)
    def panel(self, screen, *a, **k): return self._require().panel(screen, *a, **k)
    def button(self, screen, *a, **k): return self._require().button(screen, *a, **k)
    def slider(self, screen, *a, **k): return self._require().slider(screen, *a, **k)
    def textbox(self, screen, *a, **k): return self._require().textbox(screen, *a, **k)
    def checkbox(self, screen, *a, **k): return self._require().checkbox(screen, *a, **k)
    def toggle(self, screen, *a, **k): return self._require().toggle(screen, *a, **k)
    def dropdown(self, screen, *a, **k): return self._require().dropdown(screen, *a, **k)
    def progress(self, screen, *a, **k): return self._require().progress(screen, *a, **k)
    def image(self, screen, *a, **k): return self._require().image(screen, *a, **k)
ui = _NS()
