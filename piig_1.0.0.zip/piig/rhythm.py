
class RhythmClock:
    def __init__(self, bpm=120.0, offset_ms=0.0, latency_ms=0.0):
        self.bpm=bpm; self.offset=offset_ms/1000.0; self.latency=latency_ms/1000.0; self.t=0.0; self.playing=True
    def set(self, bpm=None, offset_ms=None, latency_ms=None):
        if bpm is not None: self.bpm=bpm
        if offset_ms is not None: self.offset=offset_ms/1000.0
        if latency_ms is not None: self.latency=latency_ms/1000.0
    def update(self, dt):
        if self.playing: self.t+=dt
    def sec_per_beat(self): return 60.0/self.bpm
    def song_time(self): return self.t - self.offset - self.latency
    def beat(self): return self.song_time()/self.sec_per_beat()
    def is_on_beat(self, tol_ms=40.0):
        phase=self.beat(); dist=abs(phase-round(phase)); return dist*self.sec_per_beat()<=tol_ms/1000.0
