
import pygame, os
_cache_img={}; _cache_snd={}
\1    _cache_img = globals().get('_cache_img', {})
    key=os.path.abspath(path)
    if key in _cache_img: return _cache_img[key]
    img=pygame.image.load(key).convert_alpha(); _cache_img[key]=img; return img
def sound(path):
    key=os.path.abspath(path)
    if key in _cache_snd: return _cache_snd[key]
    s=pygame.mixer.Sound(key); _cache_snd[key]=s; return s
