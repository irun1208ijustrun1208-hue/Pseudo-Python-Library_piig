
import pygame
from .simpleui import UI
KEY_NAMES = {getattr(pygame, n): n for n in dir(pygame) if n.startswith("K_")}
class KeybindGUI:
    def __init__(self, keys, path="keymap.json", palette=None):
        self.keys = keys; self.path = path; self.ui = UI(palette=palette); self.waiting=None
    def draw(self, screen, x=16, y=16, w=420, h=320):
        events = getattr(self.ui, "_events", [])
        self.ui.panel(screen, x,y,w,h, header="키 설정")
        row = y+40
        for action, keylist in list(self.keys.map.items()):
            label = f"{action} → " + ", ".join(KEY_NAMES.get(k, str(k)) for k in keylist[:2])
            self.ui.text(screen, label, x+12, row)
            if self.ui.button(screen, x+w-120, row-6, 44, 26, "변경"): self.waiting = action
            if self.ui.button(screen, x+w-70, row-6, 44, 26, "삭제"): self.keys.map[action] = []
            row += 30
        if self.ui.button(screen, x+12, y+h-34, 60, 24, "저장"): self.keys.save(self.path)
        if self.ui.button(screen, x+80, y+h-34, 60, 24, "불러옴"): self.keys.load(self.path)
        if self.waiting:
            self.ui.text(screen, f"[{self.waiting}] 새 키를 누르세요", x+160, y+h-30)
            for e in events:
                if e.type==pygame.KEYDOWN:
                    self.keys.map[self.waiting] = [e.key]; self.waiting=None; break
