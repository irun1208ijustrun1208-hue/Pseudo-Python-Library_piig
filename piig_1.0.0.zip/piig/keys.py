
import pygame, json, os

class Keys:
    def __init__(self, mapping=None):
        self.map = mapping or {
            "left": [pygame.K_LEFT, pygame.K_a],
            "right":[pygame.K_RIGHT, pygame.K_d],
            "up":[pygame.K_UP, pygame.K_w],
            "down":[pygame.K_DOWN, pygame.K_s],
            "ok":[pygame.K_RETURN, pygame.K_SPACE]
        }
        self._pressed=set(); self._held=set(); self._released=set()

    def update_from(self, events):
        self._pressed.clear(); self._released.clear()
        for e in events:
            if e.type==pygame.KEYDOWN:
                self._held.add(e.key); self._pressed.add(e.key)
            elif e.type==pygame.KEYUP:
                self._held.discard(e.key); self._released.add(e.key)

    def _update(self, events=None):
        if events is None:
            events = pygame.event.get([pygame.KEYDOWN, pygame.KEYUP])
            for e in events: pygame.event.post(e)
        self.update_from(events)

    def is_down(self, action): return any(k in self._held for k in self.map.get(action,[]))
    def pressed(self, action): return any(k in self._pressed for k in self.map.get(action,[]))
    def released(self, action): return any(k in self._released for k in self.map.get(action,[]))

    def bind(self, action, key):
        self.map.setdefault(action, [])
        if key not in self.map[action]: self.map[action].append(key)

    def save(self, path="keymap.json"):
        with open(path,"w",encoding="utf-8") as f: json.dump(self.map, f, ensure_ascii=False, indent=2)
    def load(self, path="keymap.json"):
        if os.path.exists(path):
            with open(path,"r",encoding="utf-8") as f: self.map=json.load(f)
